package listasCircularesSimples;

import java.io.IOException;

public class Aplicacion {
	
	public static void main(String args[]) throws IOException
	{
	
		ListaCircular lista=new ListaCircular();
		
		lista.insertarPrimero("AA");
		lista.insertarPrimero("BB");
		lista.insertarUltimo("ZZ");
		lista.insertarUltimo("CCC");
		//System.out.println(lista.imprimirLista());
		//lista.eliminarPrimero();
		//System.out.println(lista.imprimirLista());
		//lista.eliminarUltimo();
		//System.out.println(lista.buscarElemento("AA"));
		//System.out.println(lista.buscarElemento("CCC"));
		//System.out.println(lista.buscarElemento(0));
		System.out.println(lista.buscarElemento(3));
		System.out.println(lista.imprimirLista());
		lista.rotarLista();
		System.out.println(lista.imprimirLista());
		lista.eliminarElemento();
		//lista.eliminarElemento2();
		System.out.println(lista.imprimirLista());
		System.out.println(lista.buscarElemento(3));
			
	}

}
