package listasCircularesSimples;

public class Nodo {
	
	private String elemento;
	private Nodo nodo;
	
	public Nodo(String nuevoE, Nodo nuevoN){
		elemento=nuevoE;
		nodo=nuevoN;
	}
	
	public String getElemento(){
		return elemento;
	}
	public Nodo getNodo(){
		return nodo;
	}
	public void setElemento(String nuevoE){
		elemento=nuevoE;
	}
	public void setNodo(Nodo nuevoN){
		nodo=nuevoN;
	}

}
