package listasCircularesSimples;

public class ListaCircular {

	protected Nodo ref;
	protected long size;

	public ListaCircular(){
		ref= null;
		size=0;
	}

	public long getSize() {
		return size;
	}

	public boolean listaVacia(){
		return size==0;
	}

	public void insertarPrimero(String elemento){
		if(size==0){
			ref=new Nodo(elemento,null);
			ref.setNodo(ref);
		}
		else{
			Nodo nuevo=new Nodo(elemento, ref.getNodo());
			ref.setNodo(nuevo);

		}
		size++;
	}

	public void insertarUltimo(String elemento){
		insertarPrimero(elemento);
		ref=ref.getNodo();
	}

	public void rotarLista(){
		if(ref!=null)
			ref=ref.getNodo();
	}

	public Nodo buscarElemento(String elemento)
	{
		Nodo i=null;
		for(i=ref; i!=null; i=i.getNodo()){
			if(elemento == i.getElemento()){
				System.out.println("Elemento encontrado");
				return i;
			}	
		}
		System.out.println("Elemento no encontrado");	
		return null;
	}

	public Nodo buscarElemento(int pos)
	{
		Nodo i=null;
		int aux=0;
		for(i=ref; i!=null; i=i.getNodo()){
			if(pos == aux){
				System.out.println("Indice encontrado");
				return i;
			}	
			aux++;
		}
		System.out.println("Indice no encontrado");	
		return null;
	}
	
	public String eliminarElemento(){
		Nodo aux=ref.getNodo();
		if(listaVacia())
			return null;
		if(aux==ref)
			ref=null;
		else{
			ref.setNodo(aux.getNodo());
			System.out.println("Elemento eliminado");
		}			
		size--;
		return aux.getElemento();
	}
	
	public String imprimirLista() {
		Nodo n=null;
		String elementosLista="";
		if(listaVacia())
			return null;
		else{
			n=ref.getNodo();
			do{
				elementosLista+=n.getElemento()+"  ";
				n=n.getNodo();
			}
			while (n!=ref.getNodo());
			return elementosLista;			
		}
	}

	/*public void eliminarElemento(String elemento){
		boolean encontrar=false;
		Nodo aux=ref;
		Nodo eliminar=null;
		while((aux.getNodo()!=ref) && (!encontrar)){
			encontrar=((aux.getNodo()).getElemento()==elemento);
			if(!encontrar){
				aux=aux.getNodo();
			}
		}
		encontrar=((aux.getNodo()).getElemento()==elemento);
		if(encontrar){
			eliminar=aux.getNodo();
			if(ref==ref.getNodo())
				ref=null;
			else{
				if(eliminar==ref){
					ref=aux;
				}
				aux.getNodo();
				aux=eliminar.getNodo();
				size--;
			}
			eliminar=null;
		}
	}*/

	

}
